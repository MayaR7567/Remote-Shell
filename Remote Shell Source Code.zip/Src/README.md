# echoHttpServer

An Echo HTTP server takes the user input and print it on the screen. <br>
<br>
How to use this exampe to implement the coursework? <br>
Develop your aplication as stand-alone application and then integrate it with this simple example. <br>
<br>
How to generate the jar file? <br>
Edit the **pom.xml** file and add code bellow after the tag **\<\/project\>**. 
```
<build>
        <plugins>
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-assembly-plugin</artifactId>
                <executions>
                    <execution>
                        <phase>package</phase>
                        <goals>
                            <goal>single</goal>
                        </goals>
                        <configuration>
                        <archive>
                            <manifest>
                                <mainClass>
                                    com.mycompany.HttpEchoServer.EchoHTTPServer
                                </mainClass>
                            </manifest>
                        </archive>
                        <descriptorRefs>
                            <descriptorRef>jar-with-dependencies</descriptorRef>
                        </descriptorRefs>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
```

**NOTE** ensure that you replace com.mycompany.HttpEchoServer.EchoHTTPServer by com.mycompany.**\<PROJ_NAME\>**.**\<CLASS_NAME\>** by the project name and class name. <br>
